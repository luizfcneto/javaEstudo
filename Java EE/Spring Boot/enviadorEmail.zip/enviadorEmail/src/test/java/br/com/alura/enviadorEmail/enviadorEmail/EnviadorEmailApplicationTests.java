package br.com.alura.enviadorEmail.enviadorEmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnviadorEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
