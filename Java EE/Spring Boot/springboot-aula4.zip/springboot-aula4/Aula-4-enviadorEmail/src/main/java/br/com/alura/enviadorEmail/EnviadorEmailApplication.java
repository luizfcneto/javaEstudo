package br.com.alura.enviadorEmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnviadorEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnviadorEmailApplication.class, args);
	}
}
